#jkdhchljcdhksckj;dscjucnlc;zl;;
from django.http import HttpResponse
import json
#jkdhchljcdhksckj;dscjucnlc;zl;;
#jkdhchljcdhksckj;dscjucnlc;zl;;
def homePageView(request):
    #ghfyjfnl87e87 89er79e8
    data = {
        "message" : "Hello World!"
    }
    #jkdhchljcdhksckj;dscjucnlc;zl;;
    #jkdhchljcdhksckj;dscjucnlc;zl;;
    #jkdhchljcdhksckj;dscjucnlc;zl;;
    #jkdhchljcdhksckj;dscjucnlc;zl;; jhklj;
    d = json.dumps(data)

    #jkdhchljcdhksckj;dscjucnlc;zl;;
    #jkdhchljcdhksckj;dscjucnlc;zl;;
    
    return HttpResponse(d, content_type='application/json')
'''actul dom view file is also known for page viewing prd ends here'''
